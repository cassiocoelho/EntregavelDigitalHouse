package cachorroExercicio;

public class Animal {

    public void gritar (){
        System.out.println("gritou");
    }
}
