package cachorroExercicio;

public class Caminhar {

    String Caminhar;

    public void andar (Pessoa pessoa){
        System.out.println ("Eu \"" + pessoa.nome + "\"" + " estou andando com o \"" + pessoa.cachorro.nome + "\"");
    }

}
