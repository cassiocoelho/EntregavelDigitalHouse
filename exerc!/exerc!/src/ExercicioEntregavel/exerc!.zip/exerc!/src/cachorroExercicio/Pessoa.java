package cachorroExercicio;

public class Pessoa {

    String nome;
    Cachorro cachorro;


}
