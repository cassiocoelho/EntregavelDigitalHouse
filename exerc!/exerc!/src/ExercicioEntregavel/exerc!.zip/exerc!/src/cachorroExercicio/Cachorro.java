package cachorroExercicio;

public class Cachorro extends Animal {

    String nome;
    String raca;
    String sexo;
    int idade;

    @Override
    public void gritar (){

        System.out.println("latir");
    }


}
