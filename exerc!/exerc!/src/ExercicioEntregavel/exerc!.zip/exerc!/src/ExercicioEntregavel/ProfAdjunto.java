package ExercicioEntregavel;

public class ProfAdjunto extends Professor {

    private int qtdeHoras;
    public ProfAdjunto( String nome, String sobbrenome, int codigoProfessor, int qtdeHoras) {
        super(nome, sobbrenome, codigoProfessor, qtdeHoras);
    }

    public int getQtdeHoras() {
        return qtdeHoras;
    }

    public void setQtdeHoras( int qtdeHoras ) {
        this.qtdeHoras = qtdeHoras;
    }
}
