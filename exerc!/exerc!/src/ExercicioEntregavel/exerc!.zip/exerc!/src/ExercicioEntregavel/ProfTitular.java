package ExercicioEntregavel;

public class ProfTitular extends Professor {

    private String especialidade;
    public ProfTitular( String nome, String sobbrenome, int codigoProfessor ) {
        super(nome, sobbrenome, codigoProfessor, codigoProfessor);
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade( String especialidade ) {
        this.especialidade = especialidade;
    }
}
