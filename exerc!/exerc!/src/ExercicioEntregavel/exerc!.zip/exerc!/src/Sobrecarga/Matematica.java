package Sobrecarga;

public class Matematica {
    public int quadrado(int number){
        int quadrado;
        quadrado = number * number;
        return quadrado;
    }
    public double quadrado(double number){
        double quadrado;
        quadrado = number * number;
        return quadrado;
    }
}
