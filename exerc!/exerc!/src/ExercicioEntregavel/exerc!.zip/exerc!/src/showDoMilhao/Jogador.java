package showDoMilhao;

public class Jogador{

    public void main (String args[]){

        Jogador Cassio = new Jogador();
        System.out.print("JOGARRRR!!!!");
    }


}

