package exercicioInterface;

public interface Seguravel {

    double calcularValorApolice();
    String obterDescricao();

}
