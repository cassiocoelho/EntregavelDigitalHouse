package ExercicioEntregavel;

import java.util.List;

public class DigitalHouseManager {
    private List <Aluno> listAlunos;
    private List <Professor> listProfessor;
    private List <Curso> listCurso;
    private List <Matricula> listMatricula;


    public DigitalHouseManager() {
        this.listAlunos = listAlunos;
        this.listProfessor = listProfessor;
        this.listCurso = listCurso;
        this.listMatricula = listMatricula;
    }

    public void registrarCurso( String curso, int codigoCurso, ProfTitular profTitular, ProfAdjunto profAdjunto, int qtdeMaxima, List <Aluno> listaMatriculados ) {
        Curso novaTurma = new Curso(curso, codigoCurso, profTitular, profAdjunto, qtdeMaxima, listaMatriculados);
        this.listCurso.add(novaTurma);
    }

    public void excluirCurso( Integer codigoCurso ) {
        if (listCurso.isEmpty()) {
            System.out.println("Lista Vazia Porraaaaa!!!");
        } else {
            for (int i = 0; i < listCurso.size(); i++) {
                listCurso.remove(codigoCurso);
            }
        }
    }

    public void registrarProfessorAdjunto( String nome, String sobrenome, Integer codigoProfessor, Integer qtdeHoras ) {
        ProfAdjunto novoAdjunto = new ProfAdjunto(nome, sobrenome, codigoProfessor, qtdeHoras);
        this.listProfessor.add(novoAdjunto);

    }
}

