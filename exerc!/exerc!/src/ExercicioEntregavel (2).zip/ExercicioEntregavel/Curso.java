package ExercicioEntregavel;

import java.util.List;

public class Curso {

    private String curso;
    private int codigoCurso;
    private ProfTitular profTitular;
    private ProfAdjunto profAdjunto;
    private int qtdeMaxima;
    private List<Aluno> listaMatriculados;


    public Boolean adicionarUmAluno( Aluno umAluno ) {

        if (listaMatriculados.size() <= qtdeMaxima) {
            listaMatriculados.add(umAluno);
            return true;
        } else {
            return false;
        }
    }

    public void excluirAluno( Aluno umAluno ) {
        listaMatriculados.remove(umAluno);
    }
    public Curso( String curso, int codigoCurso, ProfTitular profTitular, ProfAdjunto profAdjunto, int qtdeMaxima, List<Aluno> listaMatriculados ) {
        this.curso = curso;
        this.codigoCurso = codigoCurso;
        this.profTitular = profTitular;
        this.profAdjunto = profAdjunto;
        this.qtdeMaxima = qtdeMaxima;
        this.listaMatriculados = listaMatriculados;
    }

    public String getMobile() {
        return curso;
    }

    public void setMobile( String mobile ) {
        this.curso = curso;
    }

    public int getCodigoCurso() {
        return codigoCurso;
    }

    public void setCodigoCurso( int codigoCurso ) {
        this.codigoCurso = codigoCurso;
    }

    public ProfTitular getProfTitular() {
        return profTitular;
    }

    public void setProfTitular( ProfTitular profTitular ) {
        this.profTitular = profTitular;
    }

    public ProfAdjunto getProfAdjunto() {
        return profAdjunto;
    }

    public void setProfAdjunto( ProfAdjunto profAdjunto ) {
        this.profAdjunto = profAdjunto;
    }

    public int getQtdeMaxima() {
        return qtdeMaxima;
    }

    public void setQtdeMaxima( int qtdeMaxima ) {
        this.qtdeMaxima = qtdeMaxima;
    }
}
