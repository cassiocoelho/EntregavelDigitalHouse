package ExercicioEntregavel;

public class Professor {
    private String nome;
    private String sobbrenome;
    private int codigoProfessor;

    public Professor( String nome, String sobbrenome, int professor, int codigoProfessor ) {
        this.nome = nome;
        this.sobbrenome = sobbrenome;
        this.codigoProfessor = codigoProfessor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome( String nome ) {
        this.nome = nome;
    }

    public String getSobbrenome() {
        return sobbrenome;
    }

    public void setSobbrenome( String sobbrenome ) {
        this.sobbrenome = sobbrenome;
    }

    public int getCodigoProfessor() {
        return codigoProfessor;
    }

    public void setCodigoProfessor( int codigoProfessor ) {
        this.codigoProfessor = codigoProfessor;
    }
}
