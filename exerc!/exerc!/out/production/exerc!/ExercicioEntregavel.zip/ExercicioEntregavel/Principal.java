package ExercicioEntregavel;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Principal {

    public static void main( String[] args ) {

        ArrayList<Curso> listinhaFofa = new ArrayList<Curso>();
        ProfTitular profTitular = new ProfTitular("Victor", "Pereira", 2222);
        ProfAdjunto profAdjunto = new ProfAdjunto("Romario", "Pereira", 1111);
      Curso mobile = new Curso("Mobile", 1234, profTitular, profAdjunto, 50, null);
        listinhaFofa.add(mobile);
        System.out.println(listinhaFofa);

        DigitalHouseManager excluir = new DigitalHouseManager();
        System.out.println("EXCLUSO");
    }
}
