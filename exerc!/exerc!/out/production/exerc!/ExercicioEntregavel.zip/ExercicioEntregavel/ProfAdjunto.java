package ExercicioEntregavel;

public class ProfAdjunto extends Professor {

    private int qtdeHoras;
    public ProfAdjunto( String nome, String sobbrenome, int codigoProfessor ) {
        super(nome, sobbrenome, codigoProfessor);
    }

    public int getQtdeHoras() {
        return qtdeHoras;
    }

    public void setQtdeHoras( int qtdeHoras ) {
        this.qtdeHoras = qtdeHoras;
    }
}
